import React from 'react'
function Aboutus() {
  return (
    <div className='container' style={{ marginTop: '30px', backgroundColor: 'skyblue', padding: '20px', borderRadius: '20px', borderBlockColor: 'ButtonHighlight', fontFamily: 'sans-serif', fontSize: '32' }}>
      <p>Himanshu (2110992040) here from G15 . This is My React Project in which i created an E-commerce Website using React and with the help of API.
        in this project i will add backend and will add Cart feature very soon.
      </p>
      <div className="ratio ratio-16x9">
        <iframe src="https://drive.google.com/file/d/1YPy8euEnpAEmDAAEKR7U18pBltblythU/view?usp=sharing" allowFullScreen title='aboutus'></iframe>
      </div>
    </div>
  )
}
export default Aboutus;
